1. I run yung mga query ng sql file sa mysql workbench
2. python app.py init_db
3. python app.py run

WAG KALIMUTAN MAG LOG OUT, PAG DIMO NA LOGOUT PAGKA RUN, NEED MO MAG FORCE CLEAR LOCAL STORAGE, GAWAN MO NG PARAAN SA JS, TAPOS EDIT MO NLANG PAGKATAPOS