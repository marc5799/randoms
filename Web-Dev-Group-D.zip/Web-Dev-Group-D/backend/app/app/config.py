
class Configuration:
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:root@localhost/itemsdatabase'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

