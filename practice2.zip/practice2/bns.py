import os

from flask import render_template, Flask, request, redirect
from flask_sqlalchemy import SQLAlchemy


project_dir = os.path.dirname(os.path.abspath(__file__))
database_file = "sqlite:///{}".format(os.path.join(project_dir, "itemsdatabase.db"))


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = database_file

db = SQLAlchemy(app)


class Item(db.Model):
    name = db.Column(db.String(80), unique=True, nullable=False, primary_key=True)
    price = db.Column(db.Integer,  nullable=False, primary_key=False)

    def __repr__(self):
        return "<Product name: {}>".format(self.name) + "<Price: {}>".format(self.price)


@app.route("/", methods=["GET", "POST"])
def home():
    items = None
    if request.form:
        try:
            item = Item(name=request.form.get("name"), price=request.form.get("price"))
            db.session.add(item)
            db.session.commit()
        except Exception as e:
            print("Failed to add Item")
            print(e)

    items = Item.query.all()
    return render_template("index.html", items=items)


@app.route("/update", methods=["POST"])
def update():
    try:
        newname = request.form.get("newname")
        oldname = request.form.get("oldname")
        item = Item.query.filter_by(name=oldname).first()
        item.name = newname

        newprice = request.form.get("newprice")
        oldprice = request.form.get("oldprice")
        item = Item.query.filter_by(price=oldprice).first()
        item.price = newprice
        db.session.commit()

    except Exception as e:
        print("Failed to update Item")
        print(e)

    return redirect("/")

@app.route("/delete", methods=["POST"])
def delete():
    name = request.form.get("name")
    item = Item.query.filter_by(name=name).first()
    db.session.delete(item)


    db.session.commit()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)