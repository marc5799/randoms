import os

from flask import render_template, Flask, request, redirect
from flask_sqlalchemy import SQLAlchemy


project_dir = os.path.dirname(os.path.abspath(__file__))
database_file = "sqlite:///{}".format(os.path.join(project_dir, "itemsdatabase.db"))


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = database_file

db = SQLAlchemy(app)



class Item(db.Model):
    item_id = db.Column(db.Integer ,unique=True, nullable=False,  primary_key = True)
    name = db.Column(db.String(80), unique=False, nullable=True)
    price = db.Column(db.Integer,  nullable=True)
    seller_name = db.Column(db.Integer, nullable=True)


    def __repr__(self):
        return "<Product name: {}>".format(self.name) + "<Price: {}>".format(self.price) + "<Item id: {}>".format(self.item_id) + "<Seller name: {}>".format(self.seller_name)

class Account(db.Model):
    account_id = db.Column(db.Integer, unique=True, nullable=False, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(80),  nullable=False, primary_key=False)

    def __repr__(self):
        return "<Username: {}>".format(self.username) + "<Password: {}>".format(self.password) + "<Acc_id: {}>".format(self.account_id)


class loggedin(db.Model):
    account_id = db.Column(db.Integer, unique=True, nullable=False, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)

    def __repr__(self):
        return "<Username: {}>".format(self.username) + "<Acc_id: {}>".format(self.account_id)


@app.route("/", methods=["GET", "POST"])
def  index():
    message = ""
    if request.form:
        try:
            if request.form.get("username") != "" and request.form.get("password") != "" and Account.query.filter_by(username=request.form.get("username")).first() == None  :
                account = Account(username=request.form.get("username"), password=request.form.get("password"))
                db.session.add(account)
                db.session.commit()
            else:
                message = "Error"
        except Exception as e:
            message = "error"
            return

    accounts = Account.query.all()
    return render_template("index.html", accounts=accounts,message = message)


@app.route("/signin", methods=["POST"])
def signin():

    if request.form :
        try:
                account = Account.query.filter_by(username=request.form.get("username")).first()
                if account.password == request.form.get("password"):
                    loggedinaccount = loggedin(username=account.username)
                    db.session.add(loggedinaccount)
                    db.session.commit()
                    return redirect("/home")
        except Exception as e:

            return redirect ("/")

    accounts = Account.query.all()
    redirect("/")
    return render_template("index.html", accounts=accounts)


@app.route("/failcreate", methods=["GET", "POST"])
def failcreate():
    if request.form:
        redirect("/sell")
    return render_template("failcreate.html")


@app.route("/sell", methods=["GET", "POST"])
def sell():
    message = ""
    accountloggedin = loggedin.query.filter_by(account_id=1).first()

    if request.form:
        if request.form.get("name") != "" and request.form.get("price") != "":
            item = Item(name=request.form.get("name"), price=request.form.get("price"), seller_name= accountloggedin.username)
            db.session.add(item)
            db.session.commit()

    items = Item.query.filter(Item.seller_name != accountloggedin.username)
    return render_template("sell.html", items=items, message = message )


@app.route("/home", methods=["GET"])
def home():
    accountloggedin = loggedin.query.all()
    return render_template("home.html", accountloggedin=accountloggedin)


@app.route("/logout", methods=["GET"])
def logout():
    db.session.query(loggedin).delete()
    db.session.commit()

    return redirect("/")


@app.route("/update", methods=["POST"])
def update():
    try:
        newname = request.form.get("newname")
        oldname = request.form.get("oldname")
        item = Item.query.filter_by(name=oldname).first()
        item.name = newname

        newprice = request.form.get("newprice")
        oldprice = request.form.get("oldprice")
        item = Item.query.filter_by(price=oldprice).first()
        item.price = newprice
        db.session.commit()

    except Exception as e:
        print("Failed to update Item")
        print(e)

    return redirect("/sell")


@app.route("/delete", methods=["POST"])
def delete():
    name = request.form.get("name")
    item = Item.query.filter_by(name=name).first()
    db.session.delete(item)


    db.session.commit()
    return redirect("/sell")


if __name__ == "__main__":
    app.run(debug=True)